package com.example.logeoevaluacion.navegation

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class NavRoutes(val route:String){
    object Alumnos_Card: NavRoutes("Alumnos_Card")
    object Login: NavRoutes("LoginScreen")
    object Home : NavRoutes(route = "AppAlumnos")
    object AddScreen : NavRoutes (route = "AddScreen")
    object PlantScreen : NavRoutes (route = "PlantScreen")
    object InfoScreen : NavRoutes (route= "InfoScreen/{nombre}/{codigo}/{curso}/{url}") {
        fun NuevaRuta (nombre:String, codigo:String, curso:String, url:String):String{
            fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
            return "InfoScreen/$nombre/$codigo/${curso.encodeUrl()}/${url.encodeUrl()}"
        }
    }
}

