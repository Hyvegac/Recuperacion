package com.example.logeoevaluacion.screens

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.logeoevaluacion.R
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class MainViewModel: ViewModel() {
    private val isLoading = MutableLiveData(false)
    private val verificar = MutableLiveData(false)

    fun isLoading(): LiveData<Boolean> = isLoading
    fun verificar(): LiveData<Boolean> = verificar

    fun LoginWithGoogle(activity: Activity){
        isLoading.postValue(true)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(activity.getString(R.string.default_web_client_id))
            .requestEmail().build()

        val client = GoogleSignIn.getClient(activity, gso)

        val singInIntent: Intent = client.getSignInIntent()
        activity.startActivityForResult(singInIntent, 1)



        //  viewModelScope.launch {
        //    delay(3000)
        //   isLoading.postValue(false)
        //   }
    }// fin del LoginWithGoogle

    fun finishLogin(accountTask: Task<GoogleSignInAccount>) {
        try {
            val account: GoogleSignInAccount? = accountTask.getResult(ApiException::class.java)

            account?.idToken?.let {
                    token ->
                val auth = FirebaseAuth.getInstance()
                val credential = GoogleAuthProvider.getCredential(token, null)

                auth.signInWithCredential(credential).addOnCompleteListener {
                        task ->
                    if(task.isSuccessful){
                        var user = auth.currentUser
                        Log.d("Ok", "Ingreso ${user?.displayName}")
                        verificar.postValue(true)
                    }else {
                        Log.d("Error", "No se pudo conectar")
                    }
                    isLoading.postValue(false)
                }
            }


        }catch (e : ApiException) {
            Log.d(ContentValues.TAG, "signInResult:failed code=" + e.statusCode)
        }
        isLoading.postValue(false)
    } // fin de la fun finishLogin

}  // Fin del MainViewModel