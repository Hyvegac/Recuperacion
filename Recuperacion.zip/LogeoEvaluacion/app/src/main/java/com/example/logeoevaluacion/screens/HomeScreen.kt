package com.example.logeoevaluacion.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.logeoevaluacion.R
import com.example.logeoevaluacion.models.Alumno
import com.example.logeoevaluacion.models.AlumnoViewModel
import com.example.logeoevaluacion.navegation.NavRoutes


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AppAlumnos (navController: NavController,viewModel: AlumnoViewModel) {
    val logo = painterResource(R.drawable.tacos)
    Scaffold(
        topBar = { TopAppBar (backgroundColor = Color.Cyan){
            Text(text = "MovieMania🎥", color = Color.Black
            )
            Spacer(modifier = Modifier
                .width(8.dp)
                .height(5.dp))
            Text(text = "Peliculas", color = Color.Black,
                modifier = Modifier.clickable{navController.navigate(route = NavRoutes.Home.route)}
                )
            Spacer(modifier = Modifier
                .width(8.dp)
                .height(5.dp))
            Text(text = "Mi Lista de Peliculas", color = Color.Black,
                modifier = Modifier.clickable{navController.navigate(route = NavRoutes.PlantScreen.route)})
        } }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    modifier = Modifier.fillMaxWidth(),
                    painter = painterResource(R.drawable.tacos),
                    contentDescription = "Logo")
                Text(text = "MovieMania es de las webs de películas gratuitas que no pueden faltar en ningún listado.", fontSize = 15.sp)
                Button(colors = ButtonDefaults.buttonColors(backgroundColor = Color.Cyan),
                    onClick = { navController.navigate(NavRoutes.AddScreen.route) }
                ){
                    Text(text = "Agregar")
                }
            }
        }
        }
    }//Fin del Scafold
