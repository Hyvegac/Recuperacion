package com.example.logeoevaluacion.models

data class Alumno(
    val nombre: String = "",
    val curso: String = "",
    val codigo: String = "",
    val url: String= ""
)