package com.example.logeoevaluacion.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.logeoevaluacion.navegation.NavRoutes

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun InfoScreen(navController: NavController, codigo:String, curso:String, nombre:String, url:String){
    Scaffold(
        topBar = { TopAppBar (backgroundColor = Color.Cyan){
            Text(text = "🎥MovieMania", color = Color.Black
            )
            Spacer(modifier = Modifier
                .width(8.dp)
                .height(5.dp))
            Text(text = "Peliculas❤", color = Color.Black
            )
            Spacer(modifier = Modifier
                .width(8.dp)
                .height(5.dp))
            Text(text = "Lista de Peliculas❤", color = Color.Black)
        } }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(text = "Nombre$nombre")
                Text(text = "Imagen$codigo")
                Box(modifier = Modifier.fillMaxWidth()){
                    Text(text = "img", color = Color.DarkGray, fontSize = 16.sp)
                    Image(painter = rememberAsyncImagePainter(curso),
                        contentDescription = "Foto : $curso",
                        modifier = Modifier.size(100.dp)
                    )
                }
                val uriHandler = LocalUriHandler.current
                Text(text = "Url $url", modifier = Modifier.clickable{
                    uriHandler.openUri(url)
                }
                )
                Button(colors = ButtonDefaults.buttonColors(backgroundColor = Color.Green),
                    onClick = { navController.navigate(NavRoutes.PlantScreen.route) }
                ){
                    Text(text = "REGRESAR")
                }
            }
        }
    }
}