package com.example.logeoevaluacion.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.logeoevaluacion.models.Alumno
import com.example.logeoevaluacion.navegation.NavRoutes
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreen (navController: NavController) {
    Scaffold(
        topBar = { TopAppBar {} },
        floatingActionButton = {
            FloatingActionButton(modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(NavRoutes.Home.route)}) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Agregar",
                    tint = Color.White
                )
            }
        },//Fin del action Button
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent(navController)
    }
}//FIN DE LA FUNCION
@Composable
fun BodyContent (navController: NavController){
    var alumnoNombre by remember { mutableStateOf("") }
    var alumnoGrupo by remember { mutableStateOf("") }
    var alumnoCodigo by remember { mutableStateOf("") }
    var alumnoUrl by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier
            .fillMaxWidth()
            .padding(all = 20.dp)) {
            TextField(modifier = Modifier.fillMaxWidth(),
                value = alumnoGrupo,
                onValueChange ={alumnoGrupo = it},
                label = { Text("Imagen de la pelicula")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(modifier = Modifier.fillMaxWidth(),
                value = alumnoNombre,
                onValueChange ={alumnoNombre = it},
                label = { Text("Nombre")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(modifier = Modifier.fillMaxWidth(),
                value = alumnoCodigo,
                onValueChange ={alumnoCodigo = it},
                label = { Text("Descripcion de la planta")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(modifier = Modifier.fillMaxWidth(),
                value = alumnoUrl,
                onValueChange ={alumnoUrl = it},
                label = { Text("Url de la pagina")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = {
                val alumno = Alumno (alumnoNombre,alumnoGrupo,alumnoCodigo, alumnoUrl)
                Firebase.firestore.collection("alumnos").add(alumno)
            },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
            ){
                Text(text = "Add Alumno")
            }
        }
    }
}