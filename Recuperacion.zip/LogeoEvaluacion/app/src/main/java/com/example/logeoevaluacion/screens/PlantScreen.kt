package com.example.logeoevaluacion.screens

import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.painterResource
import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Card
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.logeoevaluacion.models.Alumno
import com.example.logeoevaluacion.models.AlumnoViewModel
import com.example.logeoevaluacion.navegation.NavRoutes
import com.example.logeoevaluacion.R

@Composable
fun Alumnos_Card(navController: NavController,alumno: Alumno){
    Card (
        modifier = Modifier
            .padding(all = 16.dp)
            .fillMaxWidth().clickable{navController.navigate(NavRoutes.InfoScreen.NuevaRuta(alumno.nombre,alumno.codigo,alumno.curso,alumno.url))})
    {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = "Nombre : ${alumno.nombre}", color = Color.DarkGray, fontSize = 16.sp)
            Text(text = "Descripcion ${alumno.codigo}", color = Color.DarkGray, fontSize = 16.sp)
            Text(text = "Url ${alumno.url}", color = Color.DarkGray, fontSize = 16.sp)
            Box(modifier = Modifier.fillMaxWidth()){
                Text(text = "img", color = Color.DarkGray, fontSize = 16.sp)
                Image(painter = rememberAsyncImagePainter(alumno.curso),
                    contentDescription = "Foto",
                    modifier = Modifier.size(50.dp)
                )
            }
        }
    }

}
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun PlantScreen (navController: NavController,viewModel: AlumnoViewModel) {
    Scaffold(
        topBar = { TopAppBar (backgroundColor = Color.Green){
            Text(text = "MovieMania", color = Color.Black
            )
            Spacer(modifier = Modifier
                .width(8.dp)
                .height(5.dp))
            Text(text = "Peliculas", color = Color.Black,
                modifier = Modifier.clickable{navController.navigate(route = NavRoutes.Home.route)}
            )
            Spacer(modifier = Modifier
                .width(8.dp)
                .height(5.dp))
            Text(text = "Lista de Pelis", color = Color.Black,
                modifier = Modifier.clickable{navController.navigate(route = NavRoutes.PlantScreen.route)})
        } }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column() {
                LazyColumn() {
                    items(viewModel.alumnos.value) { alumno ->
                        Alumnos_Card(navController,alumno)
                    }
                }

            }

        }
    }
}//Fin de la funcion