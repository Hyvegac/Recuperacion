package com.example.logeoevaluacion.navegation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.logeoevaluacion.models.AlumnoViewModel
import com.example.logeoevaluacion.screens.*

@Composable
fun Navegacion(
    isLoading: Boolean,
    onLoginClick: () -> Unit,
    verificar: Boolean
) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = NavRoutes.Login.route) {
        composable(route = NavRoutes.InfoScreen.route, arguments= listOf(
            navArgument("nombre"){type= NavType.StringType},
            navArgument("codigo"){type= NavType.StringType},
            navArgument("curso"){type= NavType.StringType},
            navArgument("url"){type= NavType.StringType},
        )) { InfoScreen(nombre=it.arguments?.getString("nombre")?:""
            , codigo =it.arguments?.getString("codigo")?:""
            , curso= it.arguments?.getString("curso")?:""
            , url = it.arguments?.getString("url")?:"",
            navController = navController
        )
        }
        composable(route = NavRoutes.Home.route) { AppAlumnos(navController, AlumnoViewModel()) }
        composable(route = NavRoutes.AddScreen.route) { AddScreen(navController) }
        composable(route = NavRoutes.PlantScreen.route) { PlantScreen(navController, AlumnoViewModel()) }
        composable(NavRoutes.Login.route) {
            if (verificar) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(NavRoutes.Home.route){

                        popUpTo(NavRoutes.Login.route) {
                            inclusive = true
                        }

                    }

                }
            }else {
                LoginScreen(
                    isLoading = isLoading,
                    onLoginClick = onLoginClick,
                    verificar = verificar
                )
            }
        }
    }
}